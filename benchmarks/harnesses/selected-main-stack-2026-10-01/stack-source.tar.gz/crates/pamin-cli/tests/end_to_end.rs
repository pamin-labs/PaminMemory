//! Drives the actual `pamin` binary through a full lifecycle.
//!
//! Ignored by default: it provisions PostgreSQL and downloads model weights.
//! Run with `cargo test -p pamin-cli -- --ignored`.
//!
//! It invokes the binary rather than calling the library, because two defects
//! that broke every real invocation survived the library tests. The engine's
//! dynamic library is found by the test harness but not by a plainly launched
//! binary, and the engine refuses to create a collection over an existing path,
//! which only shows up on the second command against one workspace. Tests that
//! each get a fresh directory and run inside cargo see neither.

use std::path::Path;
use std::process::Command;
use std::time::{Duration, Instant};

use serde_json::Value;

/// The smallest embedding profile. This test is about the pipeline, not about
/// which model is most accurate.
const PROFILE: &str = "speed";

struct Cli {
    home: tempfile::TempDir,
}

impl Cli {
    fn new() -> Self {
        Self {
            home: tempfile::tempdir().expect("temp home"),
        }
    }

    fn home(&self) -> &Path {
        self.home.path()
    }

    fn run(&self, args: &[&str]) -> String {
        let output = Command::new(env!("CARGO_BIN_EXE_pamin"))
            .args(args)
            .env("PAMIN_HOME", self.home())
            .env("PAMIN_PROFILE", PROFILE)
            .output()
            .expect("running pamin");

        assert!(
            output.status.success(),
            "pamin {args:?} failed: {}",
            String::from_utf8_lossy(&output.stderr)
        );
        String::from_utf8(output.stdout).expect("utf-8 output")
    }

    fn json(&self, args: &[&str]) -> Value {
        let mut with_json = args.to_vec();
        with_json.push("--json");
        serde_json::from_str(&self.run(&with_json)).expect("json output")
    }

    /// Starts a server in the foreground and waits until it will answer.
    ///
    /// Ordinarily a command starts its own, and that is exactly what makes
    /// this necessary: a client that cannot reach a server starts one, so a
    /// server that died would be quietly replaced and every command would keep
    /// passing. Holding the handle is what lets a test ask whether the process
    /// that answered the first request is the one that answered the last.
    fn serve(&self) -> std::process::Child {
        self.serve_logging("warn")
    }

    /// A server whose log is part of what the test is checking.
    ///
    /// The default filter is `warn`, so a test that wants to see what the
    /// server did rather than only what it returned has to ask for it. The log
    /// is `serve.log` in the workspace either way.
    fn serve_logging(&self, filter: &str) -> std::process::Child {
        self.serve_with(filter, &[])
    }

    /// A server with `env` set as well, for a test that shortens a window.
    fn serve_with(&self, filter: &str, env: &[(&str, &str)]) -> std::process::Child {
        let log = std::fs::File::create(self.home().join("serve.log")).expect("server log");
        let child = Command::new(env!("CARGO_BIN_EXE_pamin"))
            .args(["serve"])
            .env("PAMIN_HOME", self.home())
            .env("PAMIN_PROFILE", PROFILE)
            .env("PAMIN_LOG", filter)
            .envs(env.iter().copied())
            .stdout(log.try_clone().expect("a second handle on the log"))
            .stderr(log)
            .spawn()
            .expect("starting a server");

        // The socket is bound only once the database is up and migrated, so
        // waiting for it takes as long as the startup a server exists to pay
        // once.
        let socket = self.home().join("pamin.sock");
        let deadline = Instant::now() + Duration::from_secs(300);
        while !socket.exists() {
            assert!(
                Instant::now() < deadline,
                "the server never started listening"
            );
            std::thread::sleep(Duration::from_millis(100));
        }
        child
    }

    fn fails(&self, args: &[&str]) -> String {
        let output = Command::new(env!("CARGO_BIN_EXE_pamin"))
            .args(args)
            .env("PAMIN_HOME", self.home())
            .env("PAMIN_PROFILE", PROFILE)
            .output()
            .expect("running pamin");
        assert!(!output.status.success(), "expected {args:?} to fail");
        String::from_utf8_lossy(&output.stderr).into_owned()
    }
}

impl Drop for Cli {
    fn drop(&mut self) {
        // Leaves no server behind for the next test to collide with.
        let _ = Command::new(env!("CARGO_BIN_EXE_pamin"))
            .args(["stop"])
            .env("PAMIN_HOME", self.home())
            .output();
    }
}

/// One memory per language, keyed by topic.
const MEMORIES: &[(&str, &str)] = &[
    (
        "deploy_en",
        "the deployment pipeline runs on continuous integration",
    ),
    ("deploy_zh", "部署流水线运行在持续集成上面"),
    (
        "deploy_ja",
        "デプロイパイプラインは東京のサーバーで動いています",
    ),
    ("deploy_th", "ท่อการปรับใช้ทำงานอยู่บนเซิร์ฟเวอร์"),
    ("deploy_ko", "배포 파이프라인은 서울 서버에서 실행됩니다"),
    ("deploy_ar", "خط أنابيب النشر يعمل على خادم بعيد"),
    (
        "deploy_ru",
        "конвейер развёртывания работает на удалённом сервере",
    ),
    (
        "error_ref",
        "see crates/pamin-store/src/database.rs for error E1234 in deploy_service",
    ),
];

/// A query in each language, and the topic it must reach.
const QUERIES: &[(&str, &str)] = &[
    ("continuous integration", "the deployment pipeline"),
    ("流水线", "部署流水线"),
    ("東京", "東京のサーバー"),
    ("ทำงาน", "ท่อการปรับใช้"),
    ("서울", "서울 서버"),
    ("أنابيب", "أنابيب النشر"),
    ("развёртывания", "конвейер развёртывания"),
];

/// Reranking moves what the lexical channels missed and leaves the rest.
///
/// The second pass is confined to candidates no lexical channel found, because
/// every cross-encoder measured improves cross-lingual ranking and damages
/// same-language ranking by about as much. Confining it makes the damage
/// impossible rather than unlikely, and that is the property worth holding to:
/// a candidate a lexical channel ranked comes back where fusion put it,
/// whatever the reranker thought of it.
///
/// Reverting the restriction -- reranking the whole head -- reorders those too,
/// and this fails.
#[test]
#[ignore = "provisions postgres, and downloads an embedding model and a reranker"]
fn reranking_moves_what_the_lexical_channels_missed() {
    let cli = Cli::new();
    cli.run(&["init"]);

    // Several memories sharing the query's words, so there is an order among
    // them for a reranker to disturb, and several sharing none, so there is
    // something for it to do.
    for (topic, content) in [
        (
            "deploy_en",
            "the deployment pipeline publishes signed artifacts",
        ),
        (
            "deploy_en2",
            "deployment happens after every merge to the trunk",
        ),
        (
            "deploy_en3",
            "a failed deployment rolls back to the previous tag",
        ),
        ("rota_en", "the oncall rota rotates every monday morning"),
        ("deploy_zh", "部署流水线在每次合并到主干后自动触发"),
        (
            "deploy_fr",
            "le pipeline de déploiement publie des artefacts signés",
        ),
        (
            "deploy_ja",
            "デプロイは主幹へのマージごとに自動で実行される",
        ),
        (
            "deploy_ar",
            "يتم تشغيل خط النشر تلقائيا بعد كل دمج في الفرع الرئيسي",
        ),
    ] {
        cli.run(&["write", "--topic", topic, content]);
    }

    // Each hit, and whether a lexical channel is among the reasons it is here.
    let ranked = |tier: &str| -> Vec<(String, bool)> {
        cli.json(&[
            "search",
            "how does deployment work",
            "--limit",
            "8",
            "--rerank",
            tier,
        ])["hits"]
            .as_array()
            .expect("hits")
            .iter()
            .map(|hit| {
                let lexical = hit["why"].as_array().expect("why").iter().any(|why| {
                    why["channel"]
                        .as_str()
                        .is_some_and(|channel| channel.starts_with("lexical"))
                });
                (hit["topic"].as_str().expect("a topic").to_string(), lexical)
            })
            .collect()
    };

    let plain = ranked("off");
    let reranked = ranked("fast");

    let lexical = |hits: &[(String, bool)]| -> Vec<String> {
        hits.iter()
            .filter(|(_, lexical)| *lexical)
            .map(|(topic, _)| topic.clone())
            .collect()
    };
    assert!(
        !lexical(&plain).is_empty(),
        "no candidate came from a lexical channel, so this proves nothing"
    );
    assert_eq!(
        lexical(&plain),
        lexical(&reranked),
        "reranking moved a candidate a lexical channel had already ranked"
    );

    let order = |hits: &[(String, bool)]| -> Vec<String> {
        hits.iter().map(|(topic, _)| topic.clone()).collect()
    };
    assert_ne!(
        order(&plain),
        order(&reranked),
        "reranking changed nothing at all, so this proves nothing"
    );
}

#[test]
#[ignore = "provisions postgres, and downloads an embedding model and a reranker"]
fn reranking_reorders_other_languages_and_leaves_this_one_alone() {
    let cli = Cli::new();
    cli.run(&["init"]);

    // Several memories about one subject in the query's language, so there is
    // an order among them for a reranker to disturb, and several in others, so
    // there is something for it to do.
    for (topic, content) in [
        (
            "deploy_en",
            "the deployment pipeline publishes signed artifacts",
        ),
        (
            "deploy_en2",
            "deployment happens after every merge to the trunk",
        ),
        (
            "deploy_en3",
            "a failed deployment rolls back to the previous tag",
        ),
        ("rota_en", "the oncall rota rotates every monday morning"),
        ("deploy_zh", "部署流水线在每次合并到主干后自动触发"),
        (
            "deploy_fr",
            "le pipeline de déploiement publie des artefacts signés",
        ),
        (
            "deploy_ja",
            "デプロイは主幹へのマージごとに自動で実行される",
        ),
    ] {
        cli.run(&["write", "--topic", topic, content]);
    }

    let ranked = |tier: &str| -> Vec<String> {
        cli.json(&[
            "search",
            "how does deployment work",
            "--limit",
            "7",
            "--rerank",
            tier,
        ])["hits"]
            .as_array()
            .expect("hits")
            .iter()
            .map(|hit| hit["topic"].as_str().expect("a topic").to_string())
            .collect()
    };

    let plain = ranked("off");
    let reranked = ranked("fast");

    let english = |hits: &[String]| -> Vec<String> {
        hits.iter()
            .filter(|topic| {
                topic.ends_with("_en") || topic.ends_with("_en2") || topic.ends_with("_en3")
            })
            .cloned()
            .collect()
    };
    assert_eq!(
        english(&plain),
        english(&reranked),
        "reranking moved memories written in the query's own language"
    );
    assert_ne!(
        plain, reranked,
        "reranking changed nothing at all, so this proves nothing"
    );
}

#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn a_workspace_serves_memories_in_any_language() {
    let cli = Cli::new();

    cli.run(&["init"]);

    for (topic, content) in MEMORIES {
        cli.run(&["write", "--topic", topic, content]);
    }

    every_language_is_searchable_in_its_own_words(&cli);
    exact_strings_are_found_through_the_ngram_channel(&cli);
    results_explain_where_they_came_from(&cli);
    an_english_query_reaches_memories_written_elsewhere(&cli);
    the_ledger_keeps_history_and_the_filter_keeps_evidence(&cli);
    a_write_can_state_when_its_claim_holds(&cli);
    topics_are_findable_before_you_know_their_names(&cli);
    the_index_rebuilds_from_postgres(&cli);
    a_profile_change_is_refused_rather_than_silently_wrong(&cli);
}

#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn the_graph_channel_reaches_what_nothing_else_can() {
    let cli = Cli::new();
    cli.run(&["init"]);

    // Deliberately disjoint: no shared vocabulary, no semantic proximity.
    // Anything that finds the second from a query about the first came
    // through the graph.
    cli.run(&[
        "write",
        "--topic",
        "release_process",
        "the release process cuts a tag and publishes artifacts",
    ]);
    cli.run(&[
        "write",
        "--topic",
        "office_plants",
        "the ficus by the window needs watering on thursdays",
    ]);

    edges_are_derived_from_names_without_being_asked(&cli);
    a_new_topic_is_linked_to_memories_that_already_named_it(&cli);
    derivation_works_in_languages_written_without_spaces(&cli);
    an_explicit_link_makes_the_unreachable_reachable(&cli);
    the_graph_credits_nothing_the_other_channels_already_found(&cli);
    a_result_is_never_its_own_explanation(&cli);
    an_edge_can_be_bounded_in_time(&cli);
    a_query_naming_a_topic_walks_out_from_it(&cli);
    a_retraction_says_whether_the_claim_ended_or_was_wrong(&cli);
    retracting_a_link_keeps_the_record_and_drops_the_result(&cli);
    edges_survive_the_projection_being_destroyed(&cli);
}

fn neighbor_topics(results: &Value) -> Vec<String> {
    results["neighbors"]
        .as_array()
        .expect("neighbors array")
        .iter()
        .map(|neighbor| neighbor["topic"].as_str().unwrap_or_default().to_string())
        .collect()
}

fn edges_are_derived_from_names_without_being_asked(cli: &Cli) {
    // No link command is run anywhere in this function. The edge exists
    // because the content names the topic, which is the whole claim.
    cli.run(&[
        "write",
        "--topic",
        "hotfix_process",
        "a hotfix skips the release process and ships straight from main",
    ]);

    let neighbors = cli.json(&["neighbors", "hotfix_process", "--depth", "1"]);
    let found = neighbor_topics(&neighbors);
    assert!(
        found.contains(&"release_process".to_string()),
        "naming a topic should derive an edge to it, got {found:?}"
    );

    let derived = neighbors["neighbors"]
        .as_array()
        .unwrap()
        .iter()
        .find(|neighbor| neighbor["topic"] == "release_process")
        .expect("the derived edge");
    assert_eq!(derived["derivation"], "deterministic");
    assert_eq!(derived["edge"], "mentions");

    // Rewriting unchanged content must not stack a second edge version.
    let before = neighbor_topics(&cli.json(&["neighbors", "hotfix_process", "--depth", "1"]));
    cli.run(&[
        "write",
        "--topic",
        "hotfix_process",
        "a hotfix skips the release process and ships straight from main today",
    ]);
    let after = neighbor_topics(&cli.json(&["neighbors", "hotfix_process", "--depth", "1"]));
    assert_eq!(before, after, "re-deriving the same edge changes nothing");
}

fn a_new_topic_is_linked_to_memories_that_already_named_it(cli: &Cli) {
    // Written before any topic of that name exists. Without a backfill the
    // edge would appear only if this memory happened to be rewritten later.
    cli.run(&[
        "write",
        "--topic",
        "deploy_notes",
        "everything goes out through argo_cd now",
    ]);
    cli.run(&[
        "write",
        "--topic",
        "argo_cd",
        "argo cd runs in the tools cluster",
    ]);

    let found = neighbor_topics(&cli.json(&["neighbors", "argo_cd", "--depth", "1"]));
    assert!(
        found.contains(&"deploy_notes".to_string()),
        "creating a topic should link memories that already named it, got {found:?}"
    );
}

fn derivation_works_in_languages_written_without_spaces(cli: &Cli) {
    // Nothing here is space-delimited, so a match is only possible because
    // both the name and the content pass through the same segmenter.
    cli.run(&["write", "--topic", "流水线", "流水线运行在持续集成上面"]);
    cli.run(&["write", "--topic", "回滚", "回滚会绕过流水线直接发布"]);

    let found = neighbor_topics(&cli.json(&["neighbors", "回滚", "--depth", "1"]));
    assert!(
        found.contains(&"流水线".to_string()),
        "name derivation must not depend on spaces, got {found:?}"
    );
}

/// The hit whose content contains `needle`, if the search returned one.
fn hit_containing<'a>(results: &'a Value, needle: &str) -> Option<&'a Value> {
    results["hits"]
        .as_array()
        .expect("hits")
        .iter()
        .find(|hit| hit["content"].as_str().unwrap_or_default().contains(needle))
}

/// The channels credited for one hit.
fn credited_channels(hit: &Value) -> Vec<String> {
    hit["why"]
        .as_array()
        .expect("why")
        .iter()
        .filter(|entry| entry["kind"] == "channel")
        .filter_map(|entry| entry["channel"].as_str())
        .map(str::to_string)
        .collect()
}

fn an_explicit_link_makes_the_unreachable_reachable(cli: &Cli) {
    let query = "how do we ship a release";

    // A workspace this small lets the vector channel dredge up everything, so
    // the claim under test is not "it appears" but "the graph is why it
    // appears". That is also the claim that stays true at any corpus size.
    let before = cli.json(&["search", query, "--limit", "8"]);
    if let Some(hit) = hit_containing(&before, "ficus") {
        assert!(
            !credited_channels(hit).contains(&"graph".to_string()),
            "nothing connects the plant memory yet"
        );
    }

    cli.run(&[
        "link",
        "release_process",
        "office_plants",
        "--kind",
        "related_to",
    ]);

    let after = cli.json(&["search", query, "--limit", "8"]);
    let hit = hit_containing(&after, "ficus")
        .unwrap_or_else(|| panic!("the graph should reach it: {:?}", contents(&after)));
    assert!(
        credited_channels(hit).contains(&"graph".to_string()),
        "the graph channel must be credited, got {:?}",
        credited_channels(hit)
    );

    let path = hit["why"]
        .as_array()
        .expect("why")
        .iter()
        .find(|entry| entry["kind"] == "path")
        .expect("a graph hit explains the edge it came through");
    assert_eq!(path["via"], "release_process");
    assert_eq!(path["hops"], 1);
    assert_eq!(path["edge"], "related_to");
    assert_eq!(path["derivation"], "explicit");
}

fn the_graph_credits_nothing_the_other_channels_already_found(cli: &Cli) {
    let results = cli.json(&["search", "the release process cuts a tag", "--limit", "8"]);

    for hit in results["hits"].as_array().expect("hits") {
        let why = hit["why"].as_array().expect("why");

        let graph_entries = why
            .iter()
            .filter(|entry| entry["kind"] == "channel" && entry["channel"] == "graph")
            .count();
        assert!(
            graph_entries <= 1,
            "one graph rank per result at most, got {graph_entries}"
        );

        let paths = why.iter().filter(|entry| entry["kind"] == "path").count();
        assert_eq!(
            paths, graph_entries,
            "a graph rank comes with its path and nothing else does"
        );
    }
}

fn a_result_is_never_its_own_explanation(cli: &Cli) {
    // Two topics that share no vocabulary with each other, linked. Both are
    // seeds of this query in a workspace this small, so each is genuinely
    // reachable from the other and both may be credited to the graph — that
    // is agreement between candidates, not double counting.
    //
    // What must never happen is a result being reached from itself. Traversal
    // ignores direction, so without the no-backtracking rule every seed would
    // arrive back at itself two hops along the edge it just took, and the
    // explanation would name the result it is explaining.
    cli.run(&[
        "write",
        "--topic",
        "zither_tuning",
        "the zither is tuned in fourths before every recital",
    ]);
    cli.run(&[
        "write",
        "--topic",
        "kiln_firing",
        "the kiln reaches cone ten overnight",
    ]);
    cli.run(&[
        "link",
        "zither_tuning",
        "kiln_firing",
        "--kind",
        "related_to",
    ]);

    let results = cli.json(&[
        "search",
        "tuned in fourths before a recital",
        "--limit",
        "8",
    ]);

    let reached = hit_containing(&results, "kiln").expect("the neighbour is reachable");
    assert!(
        credited_channels(reached).contains(&"graph".to_string()),
        "a topic on the far side of an edge is a genuine graph result"
    );

    for hit in results["hits"].as_array().expect("hits") {
        let topic = hit["topic"].as_str().expect("every hit names its topic");
        for path in hit["why"]
            .as_array()
            .expect("why")
            .iter()
            .filter(|entry| entry["kind"] == "path")
        {
            assert_ne!(
                path["via"], topic,
                "a result reached from itself explains nothing"
            );
            assert!(
                path["hops"].as_u64().unwrap_or(0) >= 1,
                "a path always crosses at least one edge"
            );
        }
    }
}

fn an_edge_can_be_bounded_in_time(cli: &Cli) {
    // Truth validity travels through the CLI as RFC 3339 on both sides, so a
    // timestamp the CLI prints can be handed straight back to it. The store
    // covers the filtering itself; what is checked here is the plumbing that
    // carries a bound from an argument into the query, which is where a
    // regression would be silent.
    // Neither memory names the other topic. If one did, derivation would add
    // an unbounded `mentions` edge alongside the bounded one and the temporal
    // filter would have nothing to prove.
    cli.run(&[
        "write",
        "--topic",
        "ledger_migration",
        "the rewrite ran against every account in one pass",
    ]);
    cli.run(&[
        "write",
        "--topic",
        "old_schema",
        "balances used to live in a single wide table",
    ]);
    cli.run(&[
        "link",
        "ledger_migration",
        "old_schema",
        "--kind",
        "depends_on",
        "--valid-from",
        "2020-01-01T00:00:00Z",
        "--valid-to",
        "2021-01-01T00:00:00Z",
    ]);

    let inside = cli.json(&[
        "neighbors",
        "ledger_migration",
        "--depth",
        "1",
        "--at",
        "2020-06-01T00:00:00Z",
    ]);
    assert!(
        neighbor_topics(&inside).contains(&"old_schema".to_string()),
        "the edge holds inside its own interval: {:?}",
        neighbor_topics(&inside)
    );

    let outside = cli.json(&[
        "neighbors",
        "ledger_migration",
        "--depth",
        "1",
        "--at",
        "2026-06-01T00:00:00Z",
    ]);
    assert!(
        outside["neighbors"]
            .as_array()
            .expect("neighbors")
            .is_empty(),
        "a dependency asserted only for 2020 does not hold now: {:?}",
        neighbor_topics(&outside)
    );

    // Without --at the question is "what do we still stand behind", which the
    // edge answers regardless of when it is asserted to hold.
    assert!(
        neighbor_topics(&cli.json(&["neighbors", "ledger_migration", "--depth", "1"]))
            .contains(&"old_schema".to_string()),
        "an unretracted edge is live whatever its truth interval says"
    );

    // Malformed and impossible bounds are refused rather than silently
    // reinterpreted, which is the only way a caller learns it got them wrong.
    let error = cli.fails(&["neighbors", "ledger_migration", "--at", "yesterday"]);
    assert!(error.contains("RFC 3339"), "got {error:?}");

    let error = cli.fails(&[
        "link",
        "old_schema",
        "ledger_migration",
        "--kind",
        "depends_on",
        "--valid-from",
        "2021-01-01T00:00:00Z",
        "--valid-to",
        "2020-01-01T00:00:00Z",
    ]);
    assert!(error.contains("--valid-to must be after"), "got {error:?}");
}

fn a_query_naming_a_topic_walks_out_from_it(cli: &Cli) {
    // The seeded topic's own content shares nothing with the query, so the
    // lexical and vector channels cannot reach it. Only matching the query
    // text against known topic names can, which is the retrieval half of
    // entity linking. Without it, asking about a topic by name never walks
    // out from that topic.
    cli.run(&[
        "write",
        "--topic",
        "sourdough_starter",
        "feed it twice a day and keep it warm",
    ]);
    cli.run(&[
        "write",
        "--topic",
        "rye_flour",
        "coarse ground, from the mill on the north road",
    ]);
    cli.run(&[
        "link",
        "sourdough_starter",
        "rye_flour",
        "--kind",
        "depends_on",
    ]);

    let results = cli.json(&["search", "what does sourdough_starter need", "--limit", "8"]);
    let reached = hit_containing(&results, "coarse ground").unwrap_or_else(|| {
        panic!(
            "naming a topic should walk out from it: {:?}",
            contents(&results)
        )
    });
    assert!(
        credited_channels(reached).contains(&"graph".to_string()),
        "and the graph is what reached it, got {:?}",
        credited_channels(reached)
    );

    let path = reached["why"]
        .as_array()
        .expect("why")
        .iter()
        .find(|entry| entry["kind"] == "path")
        .expect("a graph hit explains itself");
    assert_eq!(
        path["from"], "sourdough_starter",
        "the trace names the topic the walk began from"
    );
}

/// The case `a_query_naming_a_topic_walks_out_from_it` cannot reach: a named
/// topic that no index channel returned. That one runs on a workspace small
/// enough that every channel returns every topic, so the named topic was always
/// a candidate anyway. At a channel depth of one it is not, and the walk has to
/// start from the name alone -- which is the whole reason names are resolved.
///
/// Its own workspace, because at a channel depth of one the graph keeps one
/// neighbour, and in the shared one an unrelated edge of equal strength can
/// take that place and make the test about tie-breaking instead.
///
/// Content that shares nothing with the query is not enough to keep the named
/// topic out of the vector channel: a new index embeds `name: content`, so the
/// name the query spells out puts the topic near it whatever the content says.
/// That is why another memory asks the query's own question about something
/// else -- it is what each channel's one slot goes to instead.
#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn a_named_topic_seeds_the_walk_when_no_channel_found_it() {
    let cli = Cli::new();
    cli.run(&["init"]);
    cli.run(&[
        "write",
        "--topic",
        "office_plants",
        "what does the ficus by the window need? watering on thursdays",
    ]);
    cli.run(&[
        "write",
        "--topic",
        "quartz_vein",
        "painted blue on thursdays",
    ]);
    cli.run(&[
        "write",
        "--topic",
        "mine_shaft",
        "reachable only by the east ladder",
    ]);
    cli.run(&["link", "quartz_vein", "mine_shaft", "--kind", "depends_on"]);

    let results = cli.json(&[
        "search",
        "what does quartz_vein need",
        "--limit",
        "8",
        "--channel-depth",
        "1",
        "--rerank",
        "off",
    ]);

    // The premise: no index channel returned the named topic, so only its
    // name can seed the walk. If one did, this is the other test again.
    if let Some(named) = hit_containing(&results, "painted blue") {
        let credited = credited_channels(named);
        assert!(
            credited.iter().all(|channel| channel == "graph"),
            "premise: an index channel returned the named topic ({credited:?}), so this \
             does not test seeding from the name"
        );
    }

    let reached = hit_containing(&results, "east ladder").unwrap_or_else(|| {
        panic!(
            "a topic the query names should seed the walk even when no channel \
             returned it: {:?}",
            contents(&results)
        )
    });
    assert!(
        credited_channels(reached).contains(&"graph".to_string()),
        "and the graph is what reached it, got {:?}",
        credited_channels(reached)
    );
}

fn a_retraction_says_whether_the_claim_ended_or_was_wrong(cli: &Cli) {
    cli.run(&[
        "write",
        "--topic",
        "tram_line",
        "the tram runs every eleven minutes",
    ]);
    cli.run(&[
        "write",
        "--topic",
        "bus_line",
        "the bus runs every twenty minutes",
    ]);
    cli.run(&["link", "tram_line", "bus_line", "--kind", "related_to"]);

    let held = cli.json(&["neighbors", "tram_line", "--depth", "1"]);
    assert!(neighbor_topics(&held).contains(&"bus_line".to_string()));

    // Default is `closed`: the relationship ended. It stops being asserted now
    // and stays answerable for the time it did hold.
    let retracted = cli.json(&["unlink", "tram_line", "bus_line", "--kind", "related_to"]);
    assert_eq!(retracted["closed"], true);
    assert_eq!(retracted["reason"], "closed");

    assert!(
        neighbor_topics(&cli.json(&["neighbors", "tram_line", "--depth", "1"])).is_empty(),
        "a retracted relationship is not asserted now"
    );
    assert!(
        neighbor_topics(&cli.json(&[
            "neighbors",
            "tram_line",
            "--depth",
            "1",
            "--at",
            "2020-01-01T00:00:00Z",
        ]))
        .contains(&"bus_line".to_string()),
        "but it did hold before it ended, and that question has an answer"
    );

    // `deleted` says the claim was wrong, so no instant finds it.
    cli.run(&["link", "tram_line", "bus_line", "--kind", "same_as"]);
    cli.run(&[
        "unlink",
        "tram_line",
        "bus_line",
        "--kind",
        "same_as",
        "--reason",
        "deleted",
    ]);
    let historical = cli.json(&[
        "neighbors",
        "tram_line",
        "--depth",
        "1",
        "--kind",
        "same_as",
        "--at",
        "2020-01-01T00:00:00Z",
    ]);
    assert!(
        neighbor_topics(&historical).is_empty(),
        "a claim retracted as wrong never held: {:?}",
        neighbor_topics(&historical)
    );
}

fn retracting_a_link_keeps_the_record_and_drops_the_result(cli: &Cli) {
    let retracted = cli.json(&[
        "unlink",
        "release_process",
        "office_plants",
        "--kind",
        "related_to",
    ]);
    assert_eq!(retracted["closed"], true);

    let after = cli.json(&["search", "how do we ship a release", "--limit", "8"]);
    if let Some(hit) = hit_containing(&after, "ficus") {
        assert!(
            !credited_channels(hit).contains(&"graph".to_string()),
            "a retracted edge stops feeding recall"
        );
    }
    assert!(
        neighbor_topics(&cli.json(&["neighbors", "release_process", "--depth", "2"]))
            .iter()
            .all(|topic| topic != "office_plants"),
        "a retracted edge is not traversed"
    );

    // Retracting again reports that nothing was open, rather than pretending.
    let again = cli.json(&[
        "unlink",
        "release_process",
        "office_plants",
        "--kind",
        "related_to",
    ]);
    assert_eq!(again["closed"], false);
}

fn edges_survive_the_projection_being_destroyed(cli: &Cli) {
    cli.run(&[
        "link",
        "release_process",
        "office_plants",
        "--kind",
        "related_to",
    ]);

    std::fs::remove_dir_all(cli.home().join("index")).expect("delete the index");
    cli.run(&["reindex"]);

    let after = cli.json(&["search", "how do we ship a release", "--limit", "8"]);
    let hit = hit_containing(&after, "ficus")
        .unwrap_or_else(|| panic!("still reachable: {:?}", contents(&after)));
    assert!(
        credited_channels(hit).contains(&"graph".to_string()),
        "the graph lives in postgres, so a rebuilt projection changes nothing"
    );
}

fn contents(results: &Value) -> Vec<String> {
    results["hits"]
        .as_array()
        .expect("hits array")
        .iter()
        .map(|hit| hit["content"].as_str().unwrap_or_default().to_string())
        .collect()
}

fn every_language_is_searchable_in_its_own_words(cli: &Cli) {
    for (query, expected) in QUERIES {
        let found = contents(&cli.json(&["search", query, "--limit", "1"]));
        assert!(
            found.iter().any(|content| content.contains(expected)),
            "searching {query:?} should reach {expected:?}, got {found:?}"
        );
    }
}

fn exact_strings_are_found_through_the_ngram_channel(cli: &Cli) {
    // Word segmentation splits these apart, so only the n-gram field can match
    // them. Finding all three is what justifies carrying a second index field.
    for query in ["database.rs", "E1234", "deploy_service"] {
        let results = cli.json(&["search", query, "--limit", "1"]);
        let found = contents(&results);
        assert!(
            found.iter().any(|content| content.contains("E1234")),
            "searching {query:?} should reach the identifier memory, got {found:?}"
        );

        let channels: Vec<&str> = results["hits"][0]["why"]
            .as_array()
            .expect("why array")
            .iter()
            .filter(|why| why["kind"] == "channel")
            .filter_map(|why| why["channel"].as_str())
            .collect();
        assert!(
            channels.contains(&"lexical_ngram"),
            "{query:?} should be credited to the ngram channel, got {channels:?}"
        );
    }
}

fn results_explain_where_they_came_from(cli: &Cli) {
    let results = cli.json(&["search", "deployment pipeline", "--limit", "1"]);
    let hit = &results["hits"][0];
    let why = hit["why"].as_array().expect("why array");

    let channels: Vec<&str> = why
        .iter()
        .filter(|entry| entry["kind"] == "channel")
        .filter_map(|entry| entry["channel"].as_str())
        .collect();
    assert!(
        channels.contains(&"lexical_segmented")
            && channels.contains(&"lexical_ngram")
            && channels.contains(&"vector"),
        "an obvious match should be credited to every channel, got {channels:?}"
    );

    for entry in why.iter().filter(|entry| entry["kind"] == "channel") {
        assert!(
            entry["rank"].as_u64().unwrap_or(0) >= 1,
            "ranks start at one"
        );
    }

    // Each modifier at most once. Applying one twice inflates whatever it
    // measures with nothing in the trace revealing it happened.
    let mut modifiers: Vec<&str> = why
        .iter()
        .filter(|entry| entry["kind"] == "modifier")
        .filter_map(|entry| entry["modifier"].as_str())
        .collect();
    let applied = modifiers.len();
    modifiers.sort_unstable();
    modifiers.dedup();
    assert_eq!(applied, modifiers.len(), "a modifier was applied twice");

    // The span a state came from is cited by `read`, one per claim, rather
    // than by every hit of every search: no command accepts a span id, so ten
    // of them per query cost a caller tokens for something it cannot spend.
    let cited = cli.json(&["read", hit["topic"].as_str().expect("a topic name")]);
    assert!(
        !cited["source_span"].as_str().unwrap_or_default().is_empty(),
        "a state must cite the span it came from"
    );

    // What a caller can work out for itself is not sent. Weight is a constant
    // per channel and contribution is weight / (10 + rank), both printed in
    // docs/cli.md, and ten hits of them is about seven hundred tokens.
    for entry in why {
        assert!(
            entry.get("weight").is_none() && entry.get("contribution").is_none(),
            "the trace should not restate what the reader can derive: {entry}"
        );
    }
    assert!(
        hit.get("topic_state").is_none(),
        "a state id nothing accepts as an argument should not be on every hit"
    );
}

fn an_english_query_reaches_memories_written_elsewhere(cli: &Cli) {
    let results = cli.json(&["search", "how is the code deployed", "--limit", "8"]);
    let hits = results["hits"].as_array().expect("hits");

    // Lexical channels cannot cross scripts; the multilingual embedding can.
    // Reaching these proves cross-language recall without translating anything.
    let reached: Vec<_> = hits
        .iter()
        .filter(|hit| {
            let content = hit["content"].as_str().unwrap_or_default();
            content.contains("서울") || content.contains("خادم") || content.contains("流水线")
        })
        .collect();
    assert!(
        !reached.is_empty(),
        "an english query should reach non-latin memories: {:?}",
        contents(&results)
    );

    for hit in reached {
        let channels: Vec<&str> = hit["why"]
            .as_array()
            .expect("why")
            .iter()
            .filter(|why| why["kind"] == "channel")
            .filter_map(|why| why["channel"].as_str())
            .collect();
        assert!(
            channels.contains(&"vector"),
            "cross-language recall must come from the vector channel, got {channels:?}"
        );
    }
}

fn the_ledger_keeps_history_and_the_filter_keeps_evidence(cli: &Cli) {
    cli.run(&[
        "write",
        "--topic",
        "deploy_en",
        "the deployment pipeline now runs on argo",
    ]);

    let current = cli.json(&["read", "deploy_en"]);
    assert_eq!(current["version"], 2);
    assert_eq!(current["is_current"], true);

    let previous = cli.json(&["read", "deploy_en", "--version-offset", "1"]);
    assert_eq!(previous["version"], 1);
    assert_eq!(previous["is_current"], false);

    // "When did this change" is answerable only by comparing the two
    // versions' recording times, and no read surface used to carry one. The
    // ledger has held `recorded_at` and `observed_at` since the first
    // migration; `read` dropped both, so a caller could see that a topic had
    // been rewritten and never when.
    for reading in [&current, &previous] {
        for field in ["recorded_at", "observed_at"] {
            let at = reading[field].as_str().unwrap_or_default();
            assert!(
                at.contains('T') && at.len() >= 20,
                "{field} should be an RFC 3339 timestamp, got {at:?}"
            );
        }
    }
    assert!(
        previous["recorded_at"].as_str().unwrap() < current["recorded_at"].as_str().unwrap(),
        "the superseded version was recorded before the one that replaced it"
    );
    // Open unless a writer bounded them, which is what the other timeline
    // means: a claim is asserted to hold, not asserted to hold between dates.
    assert!(current["valid_from"].is_null());
    assert!(current["valid_to"].is_null());

    // Past the oldest version, resolution clamps and says how far it reached.
    let clamped = cli.json(&["read", "deploy_en", "--version-offset", "9"]);
    assert_eq!(clamped["version"], 1);
    assert_eq!(clamped["actual_version_offset"], 1);

    // Content the filter holds is still recorded as evidence, with a reason,
    // and simply does not become a topic state.
    let noise = cli.json(&["write", "--topic", "deploy_en", "ok"]);
    assert_eq!(noise["promoted"], false);
    assert!(noise["version"].is_null());
    assert!(!noise["reason"].as_str().unwrap_or_default().is_empty());
    assert!(noise["source_version"].as_u64().unwrap_or(0) > 0);

    assert_eq!(
        cli.json(&["read", "deploy_en"])["version"],
        2,
        "a held write must not advance the topic"
    );

    // Nor may it bring a topic into existence. The topic used to be created
    // before the filter ran, so a held write to a name nobody had used left an
    // empty topic behind: a name `neighbors` and the graph channel could reach
    // and that resolved to no content at all.
    let invented = cli.json(&["write", "--topic", "never_promoted", "ok"]);
    assert_eq!(invented["promoted"], false);

    let missing = cli.fails(&["read", "never_promoted"]);
    assert!(
        missing.contains("never_promoted"),
        "a topic only ever written to under the filter should not exist: {missing:?}"
    );
}

fn a_write_can_state_when_its_claim_holds(cli: &Cli) {
    // The columns existed from the first migration and nothing could write
    // them, so the bi-temporal ledger was half a ledger: relationships could
    // say when they hold and the facts they connect could not.
    let written = cli.json(&[
        "write",
        "--topic",
        "winter_timetable",
        "the winter timetable adds two evening departures",
        "--valid-from",
        "2025-11-01T00:00:00Z",
        "--valid-to",
        "2026-03-01T00:00:00Z",
    ]);
    assert_eq!(written["promoted"], true);
    assert_eq!(written["valid_from"], "2025-11-01T00:00:00Z");
    assert_eq!(written["valid_to"], "2026-03-01T00:00:00Z");

    let error = cli.fails(&[
        "write",
        "--topic",
        "winter_timetable",
        "an interval that runs backwards",
        "--valid-from",
        "2026-03-01T00:00:00Z",
        "--valid-to",
        "2025-11-01T00:00:00Z",
    ]);
    assert!(error.contains("--valid-to must be after"), "got {error:?}");

    // And a searcher has to see it. `search` carried `recorded_at` so that
    // judging staleness would not cost a `read` per hit, but recording time
    // is the wrong timeline for that judgement: everything imported in one
    // pass shares it, so it recovers the import order and calls that the
    // history. The interval the writer asserted is the one that says which of
    // two matching memories has been overtaken.
    let hit = cli.json(&[
        "search",
        "winter timetable evening departures",
        "--limit",
        "5",
    ])["hits"]
        .as_array()
        .expect("hits")
        .iter()
        .find(|hit| hit["topic"] == "winter_timetable")
        .cloned()
        .expect("the topic just written is findable");
    assert_eq!(hit["valid_from"], "2025-11-01T00:00:00Z");
    assert_eq!(hit["valid_to"], "2026-03-01T00:00:00Z");

    // Open on a topic nobody bounded, rather than filled in from the clock.
    let unbounded = cli.json(&["search", "argo deployment pipeline", "--limit", "5"])["hits"]
        .as_array()
        .expect("hits")
        .iter()
        .find(|hit| hit["topic"] == "deploy_en")
        .cloned()
        .expect("deploy_en is findable");
    assert!(unbounded["valid_from"].is_null());
    assert!(unbounded["valid_to"].is_null());
}

fn topics_are_findable_before_you_know_their_names(cli: &Cli) {
    // Every other read command needs a name to start from, and an agent
    // resuming work has none. Without this it writes to whatever name occurs
    // to it, and one memory becomes two that never meet again.
    let listed = cli.json(&["topics", "--limit", "3"]);
    let total = listed["total"].as_u64().expect("a total");
    assert!(total >= MEMORIES.len() as u64, "every write made a topic");
    assert_eq!(
        listed["topics"].as_array().expect("topics").len(),
        3,
        "the page is bounded by --limit, and the total says how much is behind it"
    );

    // The two routes fail differently, which is why both are reported. The
    // name index is exact on the segmenter's whole tokens; the content
    // channels are forgiving. A caller shown one route cannot tell an absence
    // from a miss.
    let found = |query: &str, how: &str| -> Vec<String> {
        cli.json(&["topics", query, "--limit", "8"])["topics"]
            .as_array()
            .expect("topics")
            .iter()
            .filter(|entry| entry["how"] == how || entry["how"] == "both")
            .filter_map(|entry| entry["topic"].as_str().map(str::to_string))
            .collect()
    };

    // `deploy_en`, not a topic named for the phrase in its content. These
    // three asserted against `deployment_pipeline`, which no memory here is
    // written under and none ever was -- so the first failed, the other two
    // never ran, and the negative one in the middle is the whole point of the
    // group. Nothing reported it because no workflow runs `--ignored`.
    assert!(
        found("deploy en", "name").contains(&"deploy_en".to_string()),
        "the whole name, in words, reaches the topic through the name index"
    );
    assert!(
        !found("deploy", "name").contains(&"deploy_en".to_string()),
        "the name index matches whole runs of tokens: `deploy` is not \
         `deploy en`, and claiming otherwise is what this asserts against"
    );
    assert!(
        found("deploy", "content").contains(&"deploy_en".to_string()),
        "and the forgiving route is the one that catches a half-remembered name"
    );
}

fn the_index_rebuilds_from_postgres(cli: &Cli) {
    let before = contents(&cli.json(&["search", "流水线", "--limit", "1"]));

    std::fs::remove_dir_all(cli.home().join("index")).expect("delete the index");

    let rebuilt = cli.json(&["reindex"]);
    assert!(rebuilt["indexed"].as_u64().unwrap_or(0) >= MEMORIES.len() as u64);
    assert_eq!(
        rebuilt["reused"], 0,
        "with the index deleted there is nothing to reuse: {rebuilt}"
    );

    let after = contents(&cli.json(&["search", "流水线", "--limit", "1"]));
    assert_eq!(
        before, after,
        "the projection holds nothing postgres cannot reproduce"
    );
}

fn a_profile_change_is_refused_rather_than_silently_wrong(cli: &Cli) {
    let output = Command::new(env!("CARGO_BIN_EXE_pamin"))
        .args(["--profile", "balanced", "search", "流水线"])
        .env("PAMIN_HOME", cli.home())
        .output()
        .expect("running pamin");

    assert!(!output.status.success());
    let error = String::from_utf8_lossy(&output.stderr);
    assert!(
        error.contains("reindex"),
        "a profile mismatch should say how to fix it, got {error:?}"
    );
}

/// A setting that was removed is refused, not quietly ignored.
///
/// `PAMIN_NO_SERVER=1` ran a command in the calling process. It was removed
/// when every command came to go through the server, and for a release it was
/// simply no longer read -- so whoever set it, to debug the server or to get
/// one process to reason about, got the server anyway and nothing said so.
///
/// Not ignored, and it needs no workspace: the refusal comes before anything
/// is provisioned, which is also asserted, and before a server is started.
#[test]
fn a_removed_setting_is_refused_rather_than_ignored() {
    let home = tempfile::tempdir().expect("temp home");

    for value in ["1", "0"] {
        let output = Command::new(env!("CARGO_BIN_EXE_pamin"))
            .args(["read", "deploy"])
            .env("PAMIN_HOME", home.path())
            .env("PAMIN_NO_SERVER", value)
            .output()
            .expect("running pamin");

        assert!(
            !output.status.success(),
            "PAMIN_NO_SERVER={value} should be refused"
        );
        let error = String::from_utf8_lossy(&output.stderr);
        assert!(
            error.contains("PAMIN_NO_SERVER") && error.contains("removed"),
            "PAMIN_NO_SERVER={value} refused without saying why: {error:?}"
        );
    }

    assert!(
        std::fs::read_dir(home.path())
            .expect("temp home")
            .next()
            .is_none(),
        "a refused setting should not have provisioned a workspace"
    );
}

/// A walk deeper than the graph channel goes is refused, not quietly reduced.
///
/// `--depth` was a bare `u8`, so 255 parsed. A topic's neighbourhood grows
/// multiplicatively per hop and hub topics reach five figures of degree, so
/// what that accepted was a request no project could answer. Refusing it at the
/// boundary is what tells the operator their number was not honoured; clamping
/// silently leaves them wondering why the walk stopped at four.
///
/// Not ignored, and it needs no workspace: the argument is rejected during
/// parsing, before the command reaches anything it would have to provision.
#[test]
fn a_walk_deeper_than_the_graph_channel_goes_is_refused() {
    let home = tempfile::tempdir().expect("temp home");

    for args in [
        ["neighbors", "deploy", "--depth", "255"],
        ["search", "deploy", "--graph-depth", "255"],
    ] {
        let output = Command::new(env!("CARGO_BIN_EXE_pamin"))
            .args(args)
            .env("PAMIN_HOME", home.path())
            .output()
            .expect("running pamin");

        assert!(!output.status.success(), "{args:?} should be refused");

        let error = String::from_utf8_lossy(&output.stderr);
        assert!(
            error.contains("255"),
            "{args:?} refused without saying what was wrong: {error:?}"
        );
    }

    assert!(
        std::fs::read_dir(home.path())
            .expect("temp home")
            .next()
            .is_none(),
        "a refused argument should not have provisioned a workspace"
    );
}

#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn an_unknown_profile_is_rejected_before_anything_is_provisioned() {
    let cli = Cli::new();
    let error = cli.fails(&["--profile", "enormous", "init"]);
    assert!(error.contains("enormous"), "got {error:?}");
}

#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn grep_reaches_evidence_that_search_cannot() {
    let cli = Cli::new();
    cli.run(&["init"]);

    cli.run(&[
        "write",
        "--topic",
        "incident_log",
        "the checkout service returned E5521 during the tuesday outage",
    ]);

    // Held by the filter: too short to carry a durable claim. It never became
    // a topic state and never entered the index.
    let held = cli.json(&["write", "--topic", "incident_log", "E5521"]);
    assert_eq!(held["promoted"], false);

    // Search cannot see it. That is correct behaviour, and it is also why grep
    // has to exist: a filtering mistake is only recoverable if the content is
    // reachable by some route.
    let searched = cli.json(&["search", "E5521", "--limit", "5"]);
    assert!(
        !contents(&searched)
            .iter()
            .any(|content| content.trim() == "E5521"),
        "filtered content stays off the retrieval surface: {:?}",
        contents(&searched)
    );

    let grepped = cli.json(&["grep", "E5521"]);
    let matches = grepped["matches"].as_array().expect("matches");
    assert!(
        matches
            .iter()
            .any(|hit| hit["filter_decision"] == "filtered"),
        "grep reaches what the filter held: {matches:?}"
    );
    assert!(
        matches
            .iter()
            .any(|hit| hit["filter_decision"] == "promoted"),
        "and what it promoted"
    );
    for hit in matches {
        assert!(
            !hit["filter_reason"].as_str().unwrap_or_default().is_empty(),
            "every match says why it was or was not promoted"
        );
    }

    // Any language, because nothing tokenizes here.
    cli.run(&[
        "write",
        "--topic",
        "deploy_zh",
        "部署流水线运行在持续集成上面",
    ]);
    assert!(
        !cli.json(&["grep", "持续集成"])["matches"]
            .as_array()
            .expect("matches")
            .is_empty(),
        "a literal search needs no tokenizer"
    );

    // Case sensitivity is the caller's choice.
    assert!(
        cli.json(&["grep", "e5521"])["matches"]
            .as_array()
            .expect("matches")
            .is_empty(),
        "matching is case sensitive by default"
    );
    assert!(
        !cli.json(&["grep", "e5521", "-i"])["matches"]
            .as_array()
            .expect("matches")
            .is_empty(),
        "-i folds case"
    );

    // Superseded content stays reachable, which is what makes this an audit
    // route rather than a second view of the current state.
    cli.run(&[
        "write",
        "--topic",
        "incident_log",
        "the checkout service was fixed on wednesday",
    ]);
    assert!(
        !cli.json(&["grep", "tuesday outage"])["matches"]
            .as_array()
            .expect("matches")
            .is_empty(),
        "the superseded version is still in evidence"
    );
}

#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn one_project_cannot_crowd_another_out_of_its_own_index() {
    let cli = Cli::new();
    cli.run(&["init"]);

    // Results were always filtered to the calling project, so leakage was
    // never the symptom. Depth was: with one shared collection, every channel
    // spent its candidate budget across every project, and whatever belonged
    // to another one was fetched and then thrown away. A busy neighbour could
    // therefore consume a project's entire budget and leave it with nothing.
    //
    // Asking for a depth of one makes that measurable instead of statistical.
    for (index, note) in [
        "the release checklist covers the release checklist steps",
        "the release checklist is reviewed before every release",
        "a release checklist entry blocks the release",
        "release checklist ownership rotates with the release",
        "the release checklist lives beside the release notes",
    ]
    .iter()
    .enumerate()
    {
        cli.run(&[
            "--project",
            "crowded",
            "write",
            "--topic",
            &format!("crowded_{index}"),
            note,
        ]);
    }

    cli.run(&[
        "--project",
        "quiet",
        "write",
        "--topic",
        "quiet_topic",
        "the release checklist is short here",
    ]);

    let hits = cli.json(&[
        "--project",
        "quiet",
        "search",
        "release checklist",
        "--limit",
        "8",
        "--channel-depth",
        "1",
    ]);
    let found = contents(&hits);
    assert_eq!(
        found.len(),
        1,
        "one candidate per channel must be this project's own, got {found:?}"
    );
    assert!(found[0].contains("short here"));

    // Rebuilding one project leaves the other alone, which holds because they
    // are separate directories rather than one index filtered after the fact.
    cli.run(&["--project", "quiet", "reindex"]);
    let crowded = contents(&cli.json(&[
        "--project",
        "crowded",
        "search",
        "release checklist",
        "--limit",
        "8",
    ]));
    assert!(
        crowded.len() >= 5,
        "rebuilding one project does not disturb another: {crowded:?}"
    );
}

#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn a_pre_split_workspace_is_migrated_by_reindexing() {
    // Every workspace that existed before projects had their own directory
    // takes this path exactly once, so it is worth more than a unit test on
    // the guard: what matters is that the whole route works, from the refusal
    // through the instruction it gives to the state it leaves behind.
    let cli = Cli::new();
    cli.run(&["init"]);
    cli.run(&[
        "write",
        "--topic",
        "kept_memory",
        "a durable claim that has to survive the migration",
    ]);

    // Nothing may be holding the index when the old layout appears. A workspace
    // that predates the split predates every process that will open it, so what
    // finds it is always a fresh open -- and a server that already has the
    // index open is not going to look at the directory again, correctly.
    cli.run(&["stop"]);

    // The shape a workspace had before the split: one shared collection
    // directly under the index directory.
    std::fs::create_dir_all(cli.home().join("index").join("memories"))
        .expect("simulate the old layout");

    let error = cli.fails(&["search", "durable claim"]);
    assert!(
        error.contains("reindex"),
        "refusing is only useful if it says what to run, got {error:?}"
    );

    cli.run(&["reindex"]);
    assert!(
        !cli.home().join("index").join("memories").exists(),
        "reindexing is the migration, so it clears the old layout"
    );

    let found = contents(&cli.json(&["search", "durable claim", "--limit", "1"]));
    assert!(
        found
            .iter()
            .any(|content| content.contains("has to survive")),
        "and the memories are all still there: {found:?}"
    );
}

/// A memory outlives the process that was supposed to index it.
///
/// This is the property the outbox exists for, and it is the one that is
/// invisible from a passing test: draining after the write and never queueing
/// at all look identical once both have finished. What tells them apart is a
/// process ending between the two, and `--defer` is the only way to reach that
/// moment on purpose -- the ordinary write path always drains before it
/// returns, so the gap does not exist to observe.
///
/// That process is the server: it records a memory and, a tick or two later,
/// indexes it. So the server that recorded this one is killed before its first
/// tick, and a second server started in its place. Nothing in memory survives
/// the first, and the queue is what carries the work across.
///
/// The second is sent nothing about the project before the memory is found.
/// A request would open the project, and a project that is open is caught up
/// by the ordinary path; one nobody has asked about is the case a queue left
/// by a dead server is actually in, and the one that used to wait for the next
/// write or `pamin cascade drain` before a search could find anything in it.
#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn work_a_write_left_behind_outlives_the_process_that_left_it() {
    /// Well past the upkeep tick, which is five seconds.
    const GIVE_UP_AFTER: Duration = Duration::from_secs(120);

    let cli = Cli::new();
    let log = || std::fs::read_to_string(cli.home().join("serve.log")).expect("the server log");

    // Started before anything else is run: a command finding no server starts
    // one of its own, and this one would then refuse to start beside it.
    let mut recorder = cli.serve_logging("pamin=debug");
    cli.run(&["init"]);
    let written = cli.json(&[
        "write",
        "--defer",
        "--topic",
        "deferred_memory",
        "a claim recorded by a process that never indexed it",
    ]);
    recorder
        .kill()
        .expect("killing the server that recorded it");
    recorder.wait().expect("reaping it");
    // A killed server leaves its socket file, which would read as the new
    // one listening before it is.
    std::fs::remove_file(cli.home().join("pamin.sock")).expect("removing the dead socket");

    assert_eq!(
        written["cascade"], "queued",
        "a deferred write should say the work is still owed: {written}"
    );
    assert_eq!(
        written["promoted"], true,
        "deferring changes when the index catches up, not what is recorded: {written}"
    );
    // The premise: the server that recorded it died owing the work. Had its
    // upkeep run first, what follows would test nothing.
    assert!(
        !log().contains("caught up on owed work"),
        "the recording server indexed the memory before it was killed, so \
         nothing was left behind:\n{}",
        log()
    );

    let mut server = cli.serve_logging("pamin=debug");
    let deadline = Instant::now() + GIVE_UP_AFTER;
    while !log().contains("caught up on owed work") {
        assert!(
            Instant::now() < deadline,
            "a server with nothing asked of it never caught up on the work a dead one \
             left:\n{}",
            log()
        );
        std::thread::sleep(Duration::from_millis(500));
    }

    let stored = cli.json(&["read", "deferred_memory"]);
    assert!(
        stored["content"]
            .as_str()
            .unwrap_or_default()
            .contains("never indexed it"),
        "the memory is committed whatever the index knows: {stored}"
    );
    let found = contents(&cli.json(&["search", "recorded by a process", "--limit", "5"]));
    assert!(
        found
            .iter()
            .any(|content| content.contains("never indexed")),
        "the first search after a new server caught up should find the memory: {found:?}"
    );

    // Done, not failed: nothing set aside and nothing owed.
    let owed = cli.json(&["cascade", "failed"]);
    assert_eq!(
        owed["failed"].as_array().expect("failed array").len(),
        0,
        "nothing should have failed, only waited: {owed}"
    );
    let drained = cli.json(&["cascade", "drain"]);
    assert_eq!(
        drained["pending"], 0,
        "and nothing should be left owed: {drained}"
    );

    server.kill().expect("stopping the server");
    server.wait().expect("reaping the server");
}

/// A deferred write is found without anything else being run.
///
/// `--defer` leaves the index's work in the queue and returns. Before the
/// server caught up on it, nothing ran that queue until the next write or
/// import into the same project, or `pamin cascade drain` -- so a memory
/// written this way was recorded, readable, and not searchable for as long as
/// nobody did either, which could be for ever. Against that build this fails
/// at the deadline.
///
/// The searches here are the only requests, and they are what the upkeep
/// yields to, so they are a second apart: an agent searching continuously is
/// what the catching up has to stay out of the way of, and
/// `catching_up_does_not_hold_a_search_up` is the test of that.
#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn a_deferred_write_is_found_without_anything_else_being_run() {
    /// The upkeep tick is five seconds, and a round is a fraction of one.
    const GIVE_UP_AFTER: Duration = Duration::from_secs(60);

    let cli = Cli::new();
    let mut server = cli.serve();
    cli.run(&["init"]);
    // Loads the models a search and the catching up both use, so what is
    // timed is the catching up and not a first load -- or, on a first run,
    // a download.
    cli.json(&[
        "write",
        "--topic",
        "warm_up",
        "the ferry timetable changes in october",
    ]);
    cli.json(&["search", "ferry timetable", "--limit", "5"]);

    let written = cli.json(&[
        "write",
        "--defer",
        "--topic",
        "unasked_memory",
        "the lighthouse keeper logs the fog signal every evening",
    ]);
    let recorded = Instant::now();
    // The premise: the write left the index's work owed. A write that did it
    // itself would pass this without the server doing anything.
    assert_eq!(
        written["cascade"], "queued",
        "a deferred write should leave the work owed: {written}"
    );

    let found = loop {
        let hits = contents(&cli.json(&["search", "fog signal lighthouse", "--limit", "5"]));
        if hits
            .iter()
            .any(|content| content.contains("lighthouse keeper"))
        {
            break recorded.elapsed();
        }
        assert!(
            recorded.elapsed() < GIVE_UP_AFTER,
            "a deferred write was still not searchable {GIVE_UP_AFTER:?} after it was \
             recorded, with nothing else run: {hits:?}"
        );
        std::thread::sleep(Duration::from_secs(1));
    };
    println!(
        "  searchable {:.1} s after a deferred write",
        found.as_secs_f64()
    );

    server.kill().expect("stopping the server");
    server.wait().expect("reaping the server");
}

/// A search that arrives while the server is catching up waits for at most a
/// round of it.
///
/// Catching up runs a model nobody asked for, and the searches it is doing the
/// work for share that model: a forward pass holds it, and a search on any
/// project on the same profile queues behind the pass. So the server only
/// starts a round when nothing is being answered, stops between rounds when a
/// request arrives, and keeps a round small -- and what a search can pay is
/// what is left of the round it arrived during.
///
/// The backlog is large enough to take many ticks to clear, and the searches
/// are spaced so that rounds run between them and some of them arrive during
/// one. Each is timed from outside, the way an agent would see it, against the
/// same search on the same server once the backlog is indexed and nothing is
/// owed. What this catches is the catching up holding anything a search needs
/// for longer than a round -- the model or the index across a whole tick's
/// drain, say, which is up to five seconds.
///
/// The baseline is taken after the backlog, not before it. The backlog is
/// written to resemble the query, so every memory indexed gives the search
/// more candidates to rerank: before the backlog it reranks one memory, and
/// timing against that credited the reranking of the backlog to catching up.
///
/// Two premises are checked: the server has to have caught up on something
/// during the searches, or they were timed against nothing, and it has to
/// have stopped owing anything before the baseline, or the baseline was
/// timed during catching up too.
#[test]
#[ignore = "provisions postgres and downloads model weights, and writes seven hundred memories"]
fn catching_up_does_not_hold_a_search_up() {
    /// About two thousand jobs. With nothing asked of it the server cleared three
    /// hundred memories' worth -- nine hundred -- in two ticks in this build,
    /// so this has to be more than it can clear between the last write and
    /// the first search.
    const BACKLOG: usize = 700;
    const WRITERS: usize = 6;
    const SEARCHES: usize = 30;
    /// How much slower than the slowest settled search one during catching up
    /// may be.
    ///
    /// Several rounds rather than one, because this is a debug build on a
    /// shared machine: a round of sixteen index writes took 0.3 s at the
    /// median and 1.2 s at worst here, on the `speed` profile with four cores
    /// and a load average of twelve, and across three runs the slowest search
    /// during catching up was 1.2, 1.9 and 2.5 s against 0.1, 0.4 and 0.3 s
    /// settled. What it has to rule out is a search waiting out a tick's whole
    /// budget -- five seconds, which is what holding the model or the index
    /// across the drain would cost it -- and three seconds does that with
    /// room for the machine.
    const ALLOWANCE: Duration = Duration::from_secs(3);

    let cli = Cli::new();
    let mut server = cli.serve_logging("pamin=debug");
    let log = || std::fs::read_to_string(cli.home().join("serve.log")).expect("the server log");
    let caught_up = || log().matches("caught up on owed work").count();
    cli.run(&["init"]);
    cli.json(&[
        "write",
        "--topic",
        "catch_up_marker",
        "the harbour pilot boards ships at the outer buoy",
    ]);
    cli.json(&[
        "write",
        "--topic",
        "catch_up_marker_two",
        "the harbour pilot checks the outer buoy before boarding",
    ]);

    let search = || {
        let started = Instant::now();
        let hits = contents(&cli.json(&["search", "harbour pilot outer buoy", "--limit", "5"]));
        assert!(
            hits.iter().any(|content| content.contains("harbour pilot")),
            "the search being timed found nothing, so it timed nothing: {hits:?}"
        );
        started.elapsed()
    };

    // Two visible candidates make the pass observable; one candidate skips it.
    // Wait for the actual load before any timed search.
    search();
    assert!(
        log().contains("reranker loaded"),
        "the warm-up did not load the reranker"
    );

    std::thread::scope(|scope| {
        for writer in 0..WRITERS {
            let cli = &cli;
            scope.spawn(move || {
                for memory in (writer..BACKLOG).step_by(WRITERS) {
                    cli.json(&[
                        "write",
                        "--defer",
                        "--topic",
                        &format!("backlog_{memory}"),
                        &format!(
                            "entry {memory} of the backlog records a tide table reading \
                             taken at the north pier and checked against the harbour chart"
                        ),
                    ]);
                }
            });
        }
    });

    let before = caught_up();
    let mut during = Vec::with_capacity(SEARCHES);
    for _ in 0..SEARCHES {
        std::thread::sleep(Duration::from_millis(1_000));
        during.push(search());
    }
    let rounds = caught_up() - before;

    // Settled: the whole backlog indexed and nothing owed, so the search does
    // all the reranking it did during catching up and more, and nothing runs
    // beside it.
    let drained = cli.json(&["cascade", "drain"]);
    assert_eq!(
        drained["pending"], 0,
        "work was still owed when the baseline was taken: {drained}"
    );
    let settled: Vec<Duration> = (0..10)
        .map(|_| {
            std::thread::sleep(Duration::from_millis(200));
            search()
        })
        .collect();
    let settled_slowest = *settled.iter().max().expect("settled searches");

    for line in log()
        .lines()
        .filter(|line| line.contains("caught up on owed work"))
    {
        println!("  {line}");
    }
    let slowest = *during.iter().max().expect("searches");
    println!("  settled: {settled:?}; during catching up ({rounds} catch-ups logged): {during:?}");

    assert!(
        rounds >= 2,
        "the server caught up {rounds} times while the searches ran, so they were not \
         timed against any catching up"
    );
    assert!(
        slowest <= settled_slowest + ALLOWANCE,
        "a search during catching up took {slowest:?}, against {settled_slowest:?} for the \
         slowest with nothing owed: it waited for more than a few rounds"
    );

    server.kill().expect("stopping the server");
    server.wait().expect("reaping the server");
}

/// Readers and writers share one index for long enough for the race to fire.
///
/// The projection engine declares `Sync` and does not honour it: a reader takes
/// an unsynchronized snapshot of the segments a writer is in the middle of
/// changing, reported upstream as alibaba/zvec#714. It is fixed there and not
/// released -- #715 merged as `515c11a`, against a newest published version of
/// 0.7.0 that predates it -- so what this runs against is still the code that
/// needs the lock, and this stays the test that decides when it can go. The engine
/// therefore holds a lock that the engine's own declaration says is
/// unnecessary, and nothing in a single-threaded test can tell a load-bearing
/// lock from a superstitious one. This can: sustained concurrent traffic
/// through one process, and that process still answering at the end.
///
/// Taking the lock out is what says so. Without it this fails inside a minute,
/// twice out of two runs, with searches returning `Read next record batch
/// failed (fill_result): fetch table failed` -- the reader reading a table the
/// writer had already moved. Upstream reports the same race faulting outright,
/// so an error is the mild form of it.
///
/// It also says how much lock. This ran for a long time against a read-write
/// lock, on the reading that queries may as well share the index, and the
/// engine does not agree: with readers running together it wedges inside the
/// engine's own code, forty-six of its threads asleep on futexes and no
/// processor time used by any of them. Writers alone pass; readers made
/// exclusive pass. So the lock is a mutex, and this is the test that decides
/// that rather than a benchmark, because the cost of guessing wrong is a
/// server that stops answering rather than one that answers slowly.
///
/// It covers one thing the lock deliberately does not: compaction runs on a
/// handle taken out from under it, because the engine supports queries during
/// its own maintenance and has since #614, which did ship in the version this
/// depends on. That makes compaction the one operation here genuinely
/// overlapping a query rather than queuing with it, and the seal it starts with
/// is a segment switch -- the same event #714 is about. So this is also what
/// says the narrower window is safe, and it checks the server's log at the end
/// rather than trusting that compaction happened at all.
///
/// Linux is where this shows. On macOS the same race is latent, so a green run
/// there says nothing about whether the lock is doing anything.
#[test]
#[ignore = "provisions postgres, downloads model weights, and runs for five minutes"]
fn readers_and_writers_share_one_index_without_bringing_it_down() {
    const WRITERS: usize = 20;
    const READERS: usize = 20;
    /// Long enough to be sustained rather than a burst. The upstream report
    /// puts the fault seconds into concurrent traffic, so this is minutes of
    /// margin rather than a number tuned to anything.
    const FOR_LONG_ENOUGH: Duration = Duration::from_secs(300);

    let cli = Cli::new();
    // Asked for its log, because "compaction ran" is half of what this checks
    // and the server is the only one who knows.
    let mut server = cli.serve_logging("pamin=debug");
    cli.run(&["init"]);

    let deadline = Instant::now() + FOR_LONG_ENOUGH;
    std::thread::scope(|threads| {
        for writer in 0..WRITERS {
            let cli = &cli;
            threads.spawn(move || {
                let topic = format!("stress_{writer}");
                let mut rounds = 0;
                while Instant::now() < deadline {
                    // Distinct every time. Repeating content is held in the
                    // evidence layer rather than promoted, and a held write
                    // never reaches the index, which is the thing under test.
                    let content =
                        format!("writer {writer} recorded round {rounds} of the shared index run");
                    cli.run(&["write", "--topic", &topic, &content]);
                    rounds += 1;
                }
                assert!(rounds > 0, "writer {writer} never completed a round");
            });
        }

        for reader in 0..READERS {
            let cli = &cli;
            threads.spawn(move || {
                let mut rounds = 0;
                while Instant::now() < deadline {
                    cli.run(&["search", "recorded round of the shared index run"]);
                    rounds += 1;
                }
                assert!(rounds > 0, "reader {reader} never completed a round");
            });
        }
    });

    // Every command above succeeded, which is not the same claim: a client
    // whose server had gone would have started a replacement and carried on.
    assert!(
        server.try_wait().expect("checking on the server").is_none(),
        "the server did not survive its readers and writers sharing an index"
    );

    // Flushing is what this run does concurrently with its queries: a write
    // applies its document and returns, and the server puts it on disk. That
    // takes the index lock like any other write, so the readers above are
    // sharing an index with it for the whole five minutes.
    //
    // It used to be compaction. This workload no longer fragments the index at
    // all: three thousand writes leave 136 files against a budget of 256, and
    // nothing is ever compacted. Amortizing the flush was most of what produced
    // the files, so asserting compaction here would only be asserting that the
    // old cost was still being paid.
    let log = std::fs::read_to_string(cli.home().join("serve.log")).expect("the server log");
    assert!(
        log.contains("made applied writes durable"),
        "nothing was flushed during the run, so nothing overlapped the queries \
         and a green result says nothing about whether it can"
    );

    server.kill().expect("stopping the server");
    server.wait().expect("reaping the server");
}

/// A write is findable before it is on disk, and somebody else puts it there.
///
/// The projection buffers a write in memory and a query reads that buffer, so a
/// memory is findable the moment it is applied. Making it durable is a separate
/// operation, it calls `fsync`, and it costs 39 ms -- more than everything else
/// a write does put together. Paying it per write also interrupts the engine's
/// own batching: two thousand memories flushed one at a time leave 10,031 index
/// files and 2.2 GB resident, against 25 files and 4 MB left alone.
///
/// So a write applies its document and returns, and the job stays claimed until
/// a flush covers it. Both halves need saying, and this says both: that the
/// memory is searchable straight away, and that the flush happened somewhere
/// other than in front of the writer.
///
/// What makes it safe is the claim, not the engine. Power lost between the two
/// leaves the job owed and the ledger replays it -- the same guarantee as
/// before, reached without the writer waiting for a disk.
///
/// Before this, the writer flushed its own round: the search still succeeded
/// and the server never reported making anything durable, so the second
/// assertion is the one that fails.
///
/// This replaces a test that asked the same question about compaction -- that a
/// write leaves the index's upkeep to the server rather than paying for it.
/// Compaction was the upkeep a write left behind because a write flushed, and
/// flushing per write was what produced the files: two thousand memories left
/// 10,031 index files that way and 25 left to the engine's own schedule. With
/// the flush amortized the index does not fragment at ordinary rates -- three
/// thousand writes leave 136 files against a budget of 256 -- so the old test
/// could no longer reach the state it was named for. The division of labour it
/// was about is this one; the file budget still has its own test at the index
/// layer, where the files can be produced deliberately.
#[test]
#[ignore = "provisions postgres, downloads model weights, and writes a hundred memories"]
fn a_write_is_findable_before_the_server_has_put_it_on_disk() {
    /// More than one upkeep tick's worth, so the flushing is a batch rather
    /// than one write's worth done late.
    const ENOUGH_TO_BATCH: usize = 100;
    const GIVE_UP_AFTER: Duration = Duration::from_secs(60);

    let cli = Cli::new();
    // Asked for its log, because "somebody else flushed" is half the claim.
    let mut server = cli.serve_logging("pamin=debug");
    cli.run(&["init"]);

    for round in 0..ENOUGH_TO_BATCH {
        let written = cli.json(&[
            "write",
            "--topic",
            &format!("durable_{round}"),
            &format!("round {round} of the durability run mentions marmalade"),
        ]);
        assert_eq!(
            written["cascade"], "applied",
            "a write whose document the index has is not still owed, whatever \
             the queue says about flushing it"
        );
    }

    // Findable now, with nothing having been flushed on its account.
    let hits = cli.json(&["search", "marmalade", "--limit", "5"]);
    assert!(
        !hits["hits"].as_array().expect("hits").is_empty(),
        "a memory the index has applied was not findable"
    );

    // And the server is what puts them on disk.
    let deadline = Instant::now() + GIVE_UP_AFTER;
    let flushed = loop {
        if Instant::now() > deadline {
            break false;
        }
        std::thread::sleep(Duration::from_secs(2));
        let log = std::fs::read_to_string(cli.home().join("serve.log")).expect("the server log");
        if log.contains("made applied writes durable") {
            break true;
        }
    };
    assert!(
        flushed,
        "no applied write was ever made durable by anybody but the writer"
    );

    server.kill().expect("stopping the server");
    server.wait().expect("reaping the server");
}

/// A hundred projects, and one process that can still serve them.
///
/// A project is an isolated namespace, so each one gets its own index. What
/// they do not each need is their own copy of the model: the weights that turn
/// text into a vector are the same weights whichever namespace asked, and they
/// are larger than the binary by an order of magnitude. Nor does a process need
/// to keep every index it has ever opened -- an open one holds 27 file
/// descriptors and about 100 MB resident, idle or not.
///
/// Both of those used to be unbounded, and the descriptors ran out first: this
/// failed at the thirty-seventh project, with the engine unable to create the
/// lexical indexer for the thirty-seventh index against the 1024 descriptors
/// the process started with. That is why the plain fact that a hundred projects
/// go through is most of what this asserts.
///
/// The rest is the shape of the growth. The registry fills during the first
/// fifty and holds after that, so the second fifty cost what serving costs
/// rather than what opening costs. Comparing the two halves says so without
/// naming a number: the gap is around fourfold, and unbounded retention has no
/// second half at all.
#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn a_hundred_projects_are_served_by_one_process() {
    const PROJECTS: usize = 100;

    let cli = Cli::new();
    let mut server = cli.serve();

    let idle = resident_kib(&server);
    let mut halfway = 0;

    for project in 0..PROJECTS {
        let name = format!("tenant_{project}");
        cli.run(&[
            "--project",
            &name,
            "write",
            "--topic",
            "onboarding",
            &format!("tenant {project} keeps its notes in its own namespace"),
        ]);
        cli.run(&["--project", &name, "search", "notes namespace"]);

        if project == PROJECTS / 2 - 1 {
            halfway = resident_kib(&server);
        }
    }

    let filling = halfway - idle;
    let serving = resident_kib(&server) - halfway;
    assert!(
        serving < filling,
        "the second fifty projects cost {serving} KiB against the first fifty's {filling} KiB, \
         so nothing is being let go of"
    );

    server.kill().expect("stopping the server");
    server.wait().expect("reaping the server");
}

/// A project is warmed by whatever touches it first, and the warm-up is given
/// back like anything else.
///
/// The first search after a server starts, or after it has released a
/// project, used to open the index and load the models in front of the
/// caller. A resident server now starts that when the project is first asked
/// anything, so a `grep` -- which embeds nothing -- leaves the model loaded
/// for the search that tends to follow it. What must not change is the other
/// half: a server nobody is using gives its memory back, and a model loaded
/// for a search that never came is no exception.
///
/// Before the warm-up, the `grep` loaded nothing and no warm-up was ever
/// logged, so the first assertion is the one that fails.
#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn a_warmed_project_is_given_back_when_idle() {
    const IDLE_SECONDS: &str = "15";
    const GIVE_UP_AFTER: Duration = Duration::from_secs(300);

    let cli = Cli::new();
    let mut server = cli.serve_with("pamin=debug", &[("PAMIN_MODEL_IDLE", IDLE_SECONDS)]);
    let log = || std::fs::read_to_string(cli.home().join("serve.log")).expect("the server log");
    let wait_for = |line: &str| {
        let deadline = Instant::now() + GIVE_UP_AFTER;
        while !log().contains(line) {
            assert!(
                Instant::now() < deadline,
                "the server never logged {line:?}:\n{}",
                log()
            );
            std::thread::sleep(Duration::from_millis(500));
        }
    };

    let before = resident_kib(&server);
    cli.run(&["grep", "marmalade"]);
    wait_for("warmed");
    let warmed = resident_kib(&server);
    assert!(
        warmed > before + 20 * 1024,
        "the warm-up logged success but the server grew from {before} KiB only to {warmed} KiB"
    );

    // The first release can give back only the reranker; the engine and
    // embedder go a tick later. Watch the resident size until it drops, so the
    // assertion judges the release rather than which tick it happened to see.
    wait_for("gave back what nothing had asked for");
    let enough = warmed - (warmed - before) / 2;
    let deadline = Instant::now() + GIVE_UP_AFTER;
    let mut released = resident_kib(&server);
    while released >= enough && Instant::now() < deadline {
        std::thread::sleep(Duration::from_millis(500));
        released = resident_kib(&server);
    }
    println!("  resident KiB: started {before}, warmed {warmed}, after the idle window {released}");
    assert!(
        released < enough,
        "the server held {released} KiB after the idle window, against {warmed} warmed and \
         {before} before, so the warm-up was not given back"
    );

    server.kill().expect("stopping the server");
    server.wait().expect("reaping the server");
}

/// How much memory a running process is actually holding, in KiB.
///
/// `ps` rather than `/proc`, so the measurement is the same one on every
/// platform this runs on.
fn resident_kib(server: &std::process::Child) -> u64 {
    let output = Command::new("ps")
        .args(["-o", "rss=", "-p", &server.id().to_string()])
        .output()
        .expect("asking for the server's resident size");
    assert!(output.status.success(), "the server is gone");

    String::from_utf8_lossy(&output.stdout)
        .trim()
        .parse()
        .expect("a resident size in KiB")
}

/// A topic's history is in the ledger, not in the retrieval index.
///
/// The projection used to hold one document per state. A topic edited fourteen
/// times therefore put fourteen documents into every channel's candidate
/// budget, thirteen of them saying something the topic no longer says, and all
/// fourteen competing with other topics for the fifty candidates a channel
/// returns. At the scale this store is built for -- millions of topics, a dozen
/// or so versions each -- that is a hundred million documents standing in for
/// seven million subjects.
///
/// One document per topic, holding what the topic says now. What it said before
/// is a question for `pamin read --version-offset`, which reads the ledger and
/// never goes near the index.
#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn a_topics_history_does_not_crowd_the_index() {
    const VERSIONS: usize = 6;

    let cli = Cli::new();
    cli.run(&["init"]);

    for version in 0..VERSIONS {
        cli.run(&[
            "write",
            "--topic",
            "release_process",
            &format!("the release process is at revision {version} of the rollout plan"),
        ]);
    }
    // A second topic, so a count of one is not simply a count of everything.
    cli.run(&[
        "write",
        "--topic",
        "oncall_rota",
        "the oncall rota rotates weekly",
    ]);

    // The rebuild reads the ledger and writes the index, so what it reports is
    // the index's shape. Before, this was every live state.
    let rebuilt = cli.json(&["reindex"]);
    assert_eq!(
        rebuilt["indexed"], 2,
        "two topics is two documents, whatever their histories: {rebuilt}"
    );
    assert_eq!(
        rebuilt["reused"], 2,
        "neither topic's text changed, so neither is embedded again: {rebuilt}"
    );

    // And the ranked results agree: one entry for the topic, at what it says
    // now, rather than one per revision.
    let found = cli.json(&["search", "revision of the rollout plan", "--limit", "10"]);
    let hits = found["hits"].as_array().expect("hits");
    let ours: Vec<_> = hits
        .iter()
        .filter(|hit| hit["topic"] == "release_process")
        .collect();
    assert_eq!(
        ours.len(),
        1,
        "a topic is one result however often it was rewritten: {found}"
    );
    assert_eq!(
        ours[0]["version"], VERSIONS as u64,
        "and the result is what the topic says now: {found}"
    );

    // The history is still there, just not in the index.
    let earlier = cli.json(&["read", "release_process", "--version-offset", "1"]);
    assert_eq!(earlier["version"], (VERSIONS - 1) as u64);
    assert_eq!(earlier["is_current"], false);
}

/// An import is all of the file or none of it, and what it records is findable.
///
/// The interesting half is the refusal. Memories are recorded one transaction
/// at a time, so an importer that parsed as it went would record everything
/// before a bad line and then stop -- leaving a workspace holding some unknown
/// prefix of a file, which is worse than either outcome. Parsing the whole file
/// first is what makes "it failed" mean "nothing happened".
#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn an_import_records_the_whole_file_or_none_of_it() {
    let cli = Cli::new();
    let mut server = cli.serve();
    cli.run(&["init"]);

    let broken = cli.home().join("broken.ndjson");
    std::fs::write(
        &broken,
        "{\"topic\": \"first\", \"content\": \"the deployment pipeline runs on argo cd\"}\n\
         {\"topic\": \"second\", \"content\": \"the oncall rota rotates on mondays\"}\n\
         this line is not json\n",
    )
    .expect("writing the broken file");

    let refused = Command::new(env!("CARGO_BIN_EXE_pamin"))
        .args(["import", "--from"])
        .arg(&broken)
        .env("PAMIN_HOME", cli.home())
        .env("PAMIN_PROFILE", PROFILE)
        .output()
        .expect("running import");
    assert!(
        !refused.status.success(),
        "a file with a line that is not a memory was accepted"
    );

    let after = cli.json(&["search", "deployment pipeline argo"]);
    assert!(
        after["hits"].as_array().expect("hits").is_empty(),
        "the lines before the bad one were recorded anyway: {after}"
    );

    let good = cli.home().join("good.ndjson");
    std::fs::write(
        &good,
        "{\"topic\": \"first\", \"content\": \"the deployment pipeline runs on argo cd\"}\n\
         \n\
         {\"topic\": \"second\", \"content\": \"the oncall rota rotates on mondays\"}\n",
    )
    .expect("writing the good file");

    let imported = cli.json(&["import", "--from", good.to_str().expect("a path")]);
    assert_eq!(imported["memories"], 2, "a blank line was counted");
    assert_eq!(imported["promoted"], 2);
    assert_eq!(imported["held"], 0);

    let found = cli.json(&["search", "deployment pipeline argo"]);
    assert!(
        !found["hits"].as_array().expect("hits").is_empty(),
        "an imported memory was not searchable afterwards"
    );

    // Again, unchanged. Every memory is held rather than rejected, which is
    // what makes re-running an import safe rather than an error to work around.
    let again = cli.json(&["import", "--from", good.to_str().expect("a path")]);
    assert_eq!(again["promoted"], 0);
    assert_eq!(again["held"], 2);

    server.kill().expect("stopping the server");
    server.wait().expect("reaping the server");
}

/// Two memories under one topic keep the file's order, however they are run.
///
/// The invariant that makes importing several topics at once correct rather
/// than merely faster. `Engine::remember` reads the topic's current content and
/// judges the new memory against it, and one of the verdicts is `Restatement`.
/// Two writes to one topic running at once both read the content from before
/// either of them, so the second is judged against the wrong text and a
/// restatement is promoted as though it said something new. No transaction
/// catches that -- both commit, and both are correct writes of a decision made
/// on stale input.
///
/// The file interleaves the repeat behind another topic, so an importer that
/// kept the file's order and ran it straight through would pass this by
/// accident. What has to hold is that the *second* line under `first` is
/// judged against the *first* one whatever else is in flight.
#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn one_topic_is_recorded_in_the_files_order() {
    let cli = Cli::new();
    let mut server = cli.serve();
    cli.run(&["init"]);

    let file = cli.home().join("repeats.ndjson");
    std::fs::write(
        &file,
        "{\"topic\": \"first\", \"content\": \"the deployment pipeline runs on argo cd\"}\n\
         {\"topic\": \"second\", \"content\": \"the oncall rota rotates on mondays\"}\n\
         {\"topic\": \"first\", \"content\": \"the deployment pipeline runs on argo cd\"}\n",
    )
    .expect("writing the file");

    let imported = cli.json(&["import", "--from", file.to_str().expect("a path")]);
    assert_eq!(imported["memories"], 3);
    assert_eq!(
        imported["promoted"], 2,
        "the repeat under `first` was promoted, so it was judged against the \
         content from before its own topic's earlier write: {imported}"
    );
    assert_eq!(imported["held"], 1);

    server.kill().expect("stopping the server");
    server.wait().expect("reaping the server");
}

/// The storage line of every project index in this workspace.
fn recorded_vector_indexes(cli: &Cli) -> Vec<String> {
    std::fs::read_dir(cli.home().join("index"))
        .expect("the index directory")
        .flatten()
        .filter_map(|entry| std::fs::read_to_string(entry.path().join("profile")).ok())
        .map(|marker| marker.lines().nth(2).unwrap_or_default().to_string())
        .collect()
}

/// A project's vector index is chosen when its index is built, and changed by
/// rebuilding it -- which reuses every vector rather than embedding again.
///
/// Asking an index built one way to answer as the other is refused and names
/// `pamin reindex`, as a profile change is: searched with the other index's
/// parameters it would answer, plausibly and wrongly.
#[test]
#[ignore = "provisions postgres and downloads model weights"]
fn changing_the_vector_index_takes_a_reindex_and_reuses_every_vector() {
    let cli = Cli::new();
    cli.run(&["init"]);
    for (topic, content) in [
        ("release_process", "the release train leaves on thursdays"),
        ("oncall_rota", "the oncall rota rotates weekly"),
    ] {
        cli.run(&["write", "--topic", topic, content]);
    }
    assert_eq!(recorded_vector_indexes(&cli), vec!["memory".to_string()]);
    let before = contents(&cli.json(&["search", "release train", "--limit", "1"]));
    assert_eq!(
        before,
        vec!["the release train leaves on thursdays".to_string()]
    );

    let refused = cli.fails(&["--vector-index", "disk", "search", "release train"]);
    assert!(
        refused.contains("memory") && refused.contains("reindex"),
        "the refusal has to name what the index is and what to run: {refused}"
    );

    let rebuilt = cli.json(&["--vector-index", "disk", "reindex"]);
    assert_eq!(
        rebuilt["reused"], 2,
        "changing the vector index re-embedded what the old one held: {rebuilt}"
    );
    assert_eq!(recorded_vector_indexes(&cli), vec!["disk".to_string()]);
    let after = contents(&cli.json(&[
        "--vector-index",
        "disk",
        "search",
        "release train",
        "--limit",
        "1",
    ]));
    assert_eq!(after, before);

    let refused = cli.fails(&["search", "release train"]);
    assert!(
        refused.contains("disk") && refused.contains("reindex"),
        "the default now has to be refused the other way: {refused}"
    );
}
