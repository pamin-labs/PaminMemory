//! `pamin reindex` — rebuild the projection index from PostgreSQL.
//!
//! This command is the guarantee that makes a pre-1.0 index engine acceptable:
//! whatever the index does, the authority store can reproduce it. It exists
//! from the first release so the guarantee is executable rather than stated.

use anyhow::Result;
use pamin_index::{Profile, VectorIndex};

use serde::{Deserialize, Serialize};

use crate::session::Session;

#[derive(clap::Args, Serialize, Deserialize)]
pub struct Args {}

#[derive(Serialize, Deserialize)]
pub struct Reindexed {
    /// Topics written to the projection. One document each, whatever a topic's
    /// version history holds -- searching ranks what a topic says now.
    indexed: usize,
    /// Of those, topics that kept the vector the replaced index held, because
    /// their text had not changed, rather than being embedded again.
    reused: usize,
    /// Topics whose current-state pointer disagreed with the ledger and was
    /// corrected. Zero unless something stopped maintaining it.
    repaired_pointers: u64,
    /// Topic names restated in the index that answers which topics a memory
    /// names.
    names: usize,
}

pub async fn execute(
    session: &Session,
    project: &str,
    profile: Profile,
    vector_index: VectorIndex,
    _args: Args,
) -> Result<Reindexed> {
    // Rebuilding discards this project's index first, and clears the shared
    // pre-split layout if the workspace still has one.
    let engine = session.rebuilding(project, profile, vector_index).await?;
    let rebuilt = engine.reindex().await?;

    let result = Reindexed {
        indexed: rebuilt.indexed,
        reused: rebuilt.reused,
        repaired_pointers: rebuilt.repaired_pointers,
        names: rebuilt.names,
    };
    Ok(result)
}

/// Renders the result for a person reading it.
pub fn render(result: &Reindexed) -> String {
    let mut rendered = format!(
        "Rebuilt the index from postgres: {} topics ({} reusing their stored vectors), {} topic names",
        result.indexed, result.reused, result.names
    );
    if result.repaired_pointers > 0 {
        rendered.push_str(&format!(
            "\nRepaired {} topics pointing at the wrong current state",
            result.repaired_pointers
        ));
    }
    rendered
}
