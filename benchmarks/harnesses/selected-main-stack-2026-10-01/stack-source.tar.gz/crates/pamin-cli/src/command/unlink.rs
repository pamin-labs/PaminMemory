//! `pamin unlink` — retract a relationship without erasing that it was claimed.

use anyhow::Result;
use pamin_core::TombstoneReason;
use pamin_store::graph;
use serde::{Deserialize, Serialize};

use crate::command::resolve;
use crate::session::Session;

#[derive(clap::Args, Serialize, Deserialize)]
pub struct Args {
    /// The topic the relationship starts from.
    pub from: String,

    /// The topic it points at.
    pub to: String,

    /// Which relationship to retract.
    #[arg(long, default_value = "related_to")]
    pub kind: String,

    /// Why it is being retracted, which decides what history keeps.
    ///
    /// `closed` means the relationship ended: it held until now, and queries
    /// about earlier instants still find it. `deleted` means the claim was
    /// wrong: it never held, and no query finds it at any instant.
    #[arg(long, default_value = "closed", value_parser = ["closed", "deleted"])]
    pub reason: String,
}

#[derive(Serialize, Deserialize)]
pub struct Unlinked {
    from: String,
    to: String,
    kind: String,
    reason: String,
    /// False when nothing was open to retract.
    closed: bool,
}

pub async fn execute(session: &Session, project: &str, args: Args) -> Result<Unlinked> {
    let kind = resolve::edge_kind(&args.kind)?;

    let database = session.database();
    let project = session.project(project).await?;

    let from = resolve::topic_id(database, project, &args.from).await?;
    let to = resolve::topic_id(database, project, &args.to).await?;

    // The reason is not bookkeeping. It decides whether a question about an
    // earlier instant still finds this edge: a relationship that ended did
    // hold before it ended, and one that was never true never held at all.
    // Recording both as the same retraction erases the difference and, with
    // it, the history.
    let reason = match args.reason.as_str() {
        "deleted" => TombstoneReason::Deleted,
        // The value parser admits nothing else.
        _ => TombstoneReason::Closed,
    };

    // The rows stay either way, so what was believed and when stays
    // answerable, and the truth interval is untouched.
    let closed = graph::close_edge(database.pool(), project, from, to, kind, reason).await?;

    let result = Unlinked {
        from: args.from,
        to: args.to,
        kind: kind.as_str().to_string(),
        reason: args.reason,
        closed,
    };

    Ok(result)
}

/// Renders the result for a person reading it.
pub fn render(result: &Unlinked) -> String {
    if result.closed {
        format!(
            "Retracted {} --{}--> {} ({})",
            result.from, result.kind, result.to, result.reason
        )
    } else {
        format!(
            "Nothing to retract: {} --{}--> {} was not asserted",
            result.from, result.kind, result.to
        )
    }
}
